The contents of this directory were downloaded from Ensembl on: March 14, 2012

Gene annotation files were downloaded from EnsemblGenomes release 13.

