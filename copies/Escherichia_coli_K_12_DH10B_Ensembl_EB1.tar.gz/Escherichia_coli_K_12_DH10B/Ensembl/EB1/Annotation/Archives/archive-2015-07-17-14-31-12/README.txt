The contents of the annotation directories were downloaded from Ensembl on: July 17, 2015.

Gene annotation files were downloaded from EnsemblGenomes release 27. Ensembl now uses the name 'ASM1942v1, June 2008' for this assembly.
