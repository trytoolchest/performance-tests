The contents of this directory were downloaded from Ensembl on: March 6, 2013

Gene annotation files were downloaded from EnsemblGenomes release 16. Ensembl now uses the name 'ASM942v1, Oct 2011' for this assembly.

