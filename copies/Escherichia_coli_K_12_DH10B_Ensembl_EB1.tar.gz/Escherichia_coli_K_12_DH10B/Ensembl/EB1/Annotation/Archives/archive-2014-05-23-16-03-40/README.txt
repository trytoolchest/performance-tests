The contents of the annotation directories were downloaded from Ensembl on: May 23, 2014.

Gene annotation files were downloaded from EnsemblGenomes release 22. Ensembl now uses the name 'ASM1942v1, June 2008' for this assembly.
